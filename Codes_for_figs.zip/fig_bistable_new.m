%%%%%%%%%% fig4 bistable %%%%%%%%%%
%%
figure()
binrange = 0:1:30;
p1 = histogram(distf(:),binrange,'FaceColor',[0.8 0 0],'normalization','probability'); hold on
p2 = histogram(disty(:),binrange,'FaceColor',[0 0.6 0],'normalization','probability'); hold on
p3 = histogram(distr(:),binrange,'FaceColor',[0 0 0.8],'normalization','probability');

legend([p1 p2 p3],{'Full','FSA-2','tQSSA'},'location','Northeast')
xticks([0 10 20 30])
xlim([0 30])
yticks([0 0.13 0.26])
ylim([0 0.26])
box off
legend box off
set(gca,'FontSize',13)
mean(distf)
std(distf)
mean(disty)
std(disty)
mean(distr)
std(distr)

