import numpy
import time
import os
import matplotlib.pyplot as plt
import gillespy2
from gillespy2 import Model, Species, Parameter, Reaction

class SS_lQSSA1(Model):
 def __init__(self, parameter_values=None):
    # Intialize the Model with a name of your choosing.
    Model.__init__(self, name="SS_lQSSA1")

    rate31 = Parameter(name="rate31", expression=0.1)
    rate41 = Parameter(name="rate41", expression=0.001)
    rate51 = Parameter(name="rate51", expression=0.001)
    rate61 = Parameter(name="rate61", expression=0.001)
    Kd = Parameter(name="Kd", expression=0.01)

    # Add the Parameters to the Model.
    self.add_parameter([rate31, rate41, rate51, rate61, Kd])

    MR1 = Species(name="MR1", initial_value=0)
    MA1 = Species(name="MA1", initial_value=0)
    DT1 = Species(name="DT1", initial_value=10)
    PT1 = Species(name="PT1", initial_value=10)
    # Add the Species to the Model.
    self.add_species([MR1, MA1, DT1, PT1])

    alphaR1 = Reaction(
            name="alphaR1",
            reactants={}, 
            products={MR1: 1},
            propensity_function = "rate31*(DT1-PT1+1)*(DT1-PT1+PT1*Kd)/(DT1-PT1+DT1*Kd+1)"
        )

    alphaA1 = Reaction(
            name="alphaA1",
            reactants={}, 
            products={MA1: 1},
            propensity_function = "rate41*(DT1-(DT1-PT1+1)*(DT1-PT1+PT1*Kd)/(DT1-PT1+DT1*Kd))"
        )

    betaR1 = Reaction(
            name="betaR1",
            reactants={MR1: 1}, 
            products={},
            rate=rate51
        )

    betaA1 = Reaction(
            name="betaA1",
            reactants={MA1: 1}, 
            products={},
            rate=rate61
        )

    # Add the Reactions to the Model.
    self.add_reaction([alphaR1, alphaA1, betaR1, betaA1])

    # Use NumPy to set the timespan of the Model.
    self.timespan(numpy.linspace(0, 5000, 501))

simul_num = 10000
modelred = SS_lQSSA1()

start2 = time.time()
results2 = modelred.run(number_of_trajectories = simul_num)
print(time.time() - start2)
