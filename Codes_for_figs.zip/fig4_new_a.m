clear
clc 
ATrange = 1:1000;
Kdrange = zeros(1,51);
AKrange = zeros(1,101); 
Kdsize = size(Kdrange,2);
AKsize = size(AKrange,2);
for i = 0:(Kdsize-1)
    Kdrange(i+1) = 10^(-4+i*0.04); %10^-4 ~ 10^-2 log scale
end
for i = 0:(AKsize-1)
    AKrange(i+1) = 10^(-2+i*0.04); %10^-2 ~ 10^2 log scale
end
meanX = zeros(Kdsize,AKsize,10);
tQSSAX = zeros(Kdsize,AKsize,10);
FSAX2 = zeros(Kdsize,AKsize,10);
FSAX3 = zeros(Kdsize,AKsize,10);
FSAX4 = zeros(Kdsize,AKsize,10);
FSAX5 = zeros(Kdsize,AKsize,10);

for it1 = 1:1000
    for it2 = 1:AKsize
        AT = ATrange(it1);
        AK = AKrange(it2);
        Kd = AK/AT;
        fprintf('XT=%d / Kd=%f \n',AT,Kd);
        for BT = AT:AT+9;
            tQSSAX(it1, it2,BT - AT + 1) = 1/2*(AT - BT - Kd + sqrt((AT - BT - Kd)^2 + 4*AT*Kd));
            FSAX2(it1, it2,BT - AT + 1) = FSA(AT,BT,Kd,2);
            FSAX3(it1, it2,BT - AT + 1) = FSA(AT,BT,Kd,3);
            FSAX4(it1, it2,BT - AT + 1) = FSA(AT,BT,Kd,4);
            FSAX5(it1, it2,BT - AT + 1) = FSA(AT,BT,Kd,5);
            meanX(it1, it2,BT - AT + 1) = FSA(AT,BT,Kd,AT+1);
        end
    end
end

relerrtq = abs(tQSSAX-meanX)./meanX;
relerr2 = abs(FSAX2-meanX)./meanX;
relerr3 = abs(FSAX3-meanX)./meanX;
relerr4 = abs(FSAX4-meanX)./meanX;
relerr5 = abs(FSAX5-meanX)./meanX;

%%
maxrelerrtq = max(relerrtq,[],3);
figure()
imagesc(AKrange,ATrange,log10(maxrelerrtq)); hold on
colorbar
set(gca, 'Xscale','log')
set(gca, 'Yscale','log')
set(gca,'XMinorTick','off')
set(gca,'YMinorTick','off')

set(gca,'YDir','normal')
yticks([0.0001 0.001 0.01])
% xticks([0.01 0.1 1 10 100])
xlim([0.01 100])
ylim([1 1000])
set(gca,'FontSize',13)

caxis([-2 2])
colorbar('Ticks',[-2 0 2],'Ticklabels',[0.01 1 100])
cmap = flip(hot);
colormap(cmap);

%%
maxrelerr2 = max(relerr2,[],3);
figure()
imagesc(AKrange,Kdrange,log10(maxrelerr2)); hold on
colorbar
set(gca, 'Xscale','log')
set(gca, 'Yscale','log')
set(gca,'XMinorTick','off')
set(gca,'YMinorTick','off')

set(gca,'YDir','normal')
yticks([0.0001 0.001 0.01])
xticks([0.01 0.1 1 10 100])
xlim([0.01 100])
ylim([0.0001 0.01])
set(gca,'FontSize',13)

caxis([-2 2])
colorbar('Ticks',[-2 0 2],'Ticklabels',[0.01 1 100])
cmap = flip(hot);
colormap(cmap);