%% Fig Oscillation new
clear
clc
%% Fig 3-1-d
figure()
% plot
perange = 0:10:300;
histogram(periodf,perange,'FaceColor',[0.8 0 0],'normalization','probability'); hold on
histogram(periodr,perange,'FaceColor',[0 0.6 0],'normalization','probability'); hold on
histogram(periody,perange,'FaceColor',[0 0 0.8],'normalization','probability');
alpha(.7)
legend('Full', 'FSP-2','tQSSA')
box off
legend box off
xticks([0 150 300])
xlim([0 300])
yticks([0 0.06 0.12])

ax = gca;
ax.FontSize = 13;

meanperf = mean(periodf);
stdperf = std(periodf);
meanperr = mean(periodr);
stdperr = std(periodr);
