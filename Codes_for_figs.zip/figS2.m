clear
clc
%% Error term calculation
BT = 10;
ATrange = 1:1000;
Kdrange = zeros(1,25);

ATsize = size(ATrange,2);
Kdsize = size(Kdrange,2);

for i = 0:(Kdsize-1)
    Kdrange(i+1) = 10^(-2+i*0.2); %10^-4 ~ 10^2 log scale
end

meanA = zeros(ATsize,Kdsize);
meanB = zeros(ATsize,Kdsize);
meanC = zeros(ATsize,Kdsize);
sQSSAA = zeros(ATsize,Kdsize);
sQSSAB = zeros(ATsize,Kdsize);
sQSSAC = zeros(ATsize,Kdsize);
tQSSAA = zeros(ATsize,Kdsize);
tQSSAB = zeros(ATsize,Kdsize);
tQSSAC = zeros(ATsize,Kdsize);
sQSSABnew = zeros(ATsize,Kdsize);
sQSSACnew = zeros(ATsize,Kdsize);

%% Iteration
for it1 = 1:ATsize
        for it3 = 1:Kdsize
            AT = ATrange(it1); 
            Kd = Kdrange(it3); 
            fprintf('AT=%d / BT=%d / Kd=%f \n',AT,BT,Kd);
            tQSSAA(it1, it3) = 1/2*(AT - BT - Kd + sqrt((AT+BT+Kd)^2 - 4*AT*BT));
            tQSSAB(it1, it3) = BT - AT + tQSSAA(it1, it3);
            tQSSAC(it1, it3) = AT - tQSSAA(it1, it3);
            sQSSAA(it1, it3) = AT;
            sQSSAB(it1, it3) = BT*Kd/(AT + Kd);
            sQSSAC(it1, it3) = BT*AT/(AT + Kd);
            CT = min(AT,BT);
            meanA(it1, it3) = FSA(AT,BT,Kd, min(AT,BT)+1);
            meanB(it1, it3) = BT - AT + meanA(it1,it3);
            meanC(it1, it3) = AT - meanA(it1,it3);
            sQSSACnew(it1, it3) = BT*(AT-meanC(it1, it3))/((AT-meanC(it1, it3)) + Kd);
            sQSSABnew(it1, it3) = BT*Kd/((AT-meanC(it1, it3)) + Kd);
        end
end
%% Error 
abserrA = abs(sQSSAA - meanA);
abserrB = abs(sQSSAB - meanB);
abserrC = abs(sQSSAC - meanC);

relerrA = abserrA./meanA;
relerrB = abserrB./meanB;
relerrC = abserrC./meanC;

%% tqError 
abserrAtq = abs(tQSSAA - meanA);
abserrBtq = abs(tQSSAB - meanB);
abserrCtq = abs(tQSSAC - meanC);

relerrAtq = abserrAtq./meanA;
relerrBtq = abserrBtq./meanB;
relerrCtq = abserrCtq./meanC;

%% newError 
abserrBnew = abs(sQSSABnew - meanB);
abserrCnew = abs(sQSSACnew - meanC);

relerrBnew = abserrBnew./meanB;
relerrCnew = abserrCnew./meanC;


%%
    figure()
    imagesc(log10(relerrB)); hold on
    caxis([-2 2])
    xticks(1:5:25)
    xticklabels(string(Kdrange(1:5:25)))
    set(gca,'FontSize',13)
    set(gca,'YDir','normal')
    colorbar
    colorbar('Ticks',[-2 0 2],'Ticklabels',{'10^{-2}' '10^0' '10^2'})
    cmap = flip(hot);
    colormap( cmap );  %// create colormap
    xlabel('Kd')
    ylabel('AT')
    title('Csq rel-Error / BT = 10')
    
%%
    figure()
    imagesc(log10(relerrBtq)); hold on
    caxis([-2 2])
    xticks(1:5:25)
    xticklabels(string(Kdrange(1:5:25)))
    set(gca,'FontSize',13)
    set(gca,'YDir','normal')
    colorbar
    colorbar('Ticks',[-2 0 2],'Ticklabels',{'10^{-2}' '10^0' '10^2'})
    cmap = flip(hot);
    colormap( cmap );  %// create colormap
    xlabel('Kd')
    ylabel('AT')
    title('Btq rel-Error / BT = 10')
    
%%
    figure()
    imagesc(log10(relerrBnew)); hold on
    caxis([-2 2])
    xticks(1:5:25)
    xticklabels(string(Kdrange(1:5:25)))
    set(gca,'FontSize',13)
    set(gca,'YDir','normal')
    colorbar
    colorbar('Ticks',[-2 0 2],'Ticklabels',{'10^{-2}' '10^0' '10^2'})
    cmap = flip(hot);
    colormap( cmap );  %// create colormap
    xlabel('Kd')
    ylabel('AT')
    title('Bnew rel-Error / BT = 10')