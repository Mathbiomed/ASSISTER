%% Fig 3 (b)
clear
clc
%% mean std
Xmeanf = squeeze(mean(simuldataf,1));
Xstdf = squeeze(std(simuldataf,1));

Xmeanr = squeeze(mean(simuldatar,1));
Xstdr = squeeze(std(simuldatar,1));

Xmeany = squeeze(mean(simuldatay,1));
Xstdy = squeeze(std(simuldatay,1));

Xmeanplusstdf = Xmeanf + Xstdf;
Xmeanminusstdf = Xmeanf - Xstdf;
Xmeanplusstdr = Xmeanr + Xstdr;
Xmeanminusstdr = Xmeanr - Xstdr;
Xmeanplusstdy = Xmeany + Xstdy;
Xmeanminusstdy = Xmeany - Xstdy;


%% M1 mean trajectory
figure()
patch([time_scale fliplr(time_scale)], [Xmeanplusstdf(4,:)  fliplr(Xmeanminusstdf(4,:))],[0.8 0 0], 'EdgeColor','None'); hold on;
alpha(.3)
p1 = plot(time_scale,Xmeanf(4,:),'r','LineWidth',2); hold on

patch([time_scale fliplr(time_scale)], [Xmeanplusstdr(4,:)  fliplr(Xmeanminusstdr(4,:))],[0 0 0.8], 'EdgeColor','None'); hold on;
alpha(.3)
p2 = plot(time_scale,Xmeanr(4,:),'b','LineWidth',2); hold on

% patch([time_scale fliplr(time_scale)], [Xmeanplusstdy(4,:)  fliplr(Xmeanminusstdy(4,:))],[0 0 0.8], 'EdgeColor','None'); hold on;
% alpha(.3)
% p3 = plot(time_scale,Xmeany(4,:),'b','LineWidth',2); hold on

legend([p1 p2 ],{'Full','lQSSA'},'location','northwest')
xlabel("time",'FontSize',15);
xticks([0 2500 5000])
yticks([0 9 15])
ylim([0 15])
box off
legend box off
set(gca,'FontSize',13)

%% M1 Histogram
figure()
histogram(squeeze(simuldataf(:,4,end)),'FaceColor',[0.8 0 0],'Normalization','Probability')
alpha(.7)
box off

figure()
histogram(squeeze(simuldatar(:,4,end)),'FaceColor',[0 0.8 0],'Normalization','Probability')
alpha(.7)
box off

figure()
histogram(squeeze(simuldatay(:,4,end)),'FaceColor',[0 0 0.8],'Normalization','Probability')
alpha(.7)
box off

%% save
save('fig_ss_new','-v7.3')