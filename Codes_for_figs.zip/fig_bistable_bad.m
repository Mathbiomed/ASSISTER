%%%%%%%%%% Toy4 SSA Same no PF QSSA %%%%%%%%%%
%% initialization
rng('shuffle')
Tmax = 2000; %maximal simualtion time
Fs = 10; %sampling rate
period = 1/Fs;
t = 0; %current time

%conserved variables
XT = 10;
CT = 30;
C0 = 0;

%fast reaction const
kf = 10000;
kb = 10;
Km = kb/kf;

%slow reaction const
kp = 0.6;
ka = 1000;
ki = 100;
Kd = ka/ki;
e = 0.05;
f = 1.1;
D = 1;

time_scale = 0:period:Tmax; % record time scale
scale_size = length(time_scale); % number of record time
simulnum = 10000; % number of simulations

%% full model simulation
var_num = 6;
reac_num = 8;
gamma = [0 0 1 1 -1 -1 0 0; -1 1 -1 0 1 1 0 0; -1 1 0 1 0 0 0 0;
    1 -1 0 -1 0 0 0 0; 0 0 0 0 0 0 -1 1; 0 0 0 0 0 0 1 -1];

simuldataf = zeros(simulnum,var_num,scale_size); %simulation record data full

%% Simulation
for i = 1:simulnum
    fprintf('Simulation %d\n',i);
    t = 0; %current time
    k = [CT-C0; C0; XT; 0; D; 0]; %initial condition
    X = zeros(var_num, scale_size); %X(t)
    j = 1; %iterator
    %% iteration
    while t <= Tmax
        %Omega = 1
        rho = [kf*k(2)*k(3); kb*k(4); kp*k(2); kp*k(4); e*k(5)*k(1); f*k(6)*k(1); ka*k(2)*k(5); ki*k(6)];
        lambda = sum(rho);
        
        r = rand([2 1]); %two random numbers r1, r2
        T = -1/lambda * log(r(1));
        
        if t + T > Tmax %end condition
            while j <= scale_size
                X(:,j) = k;
                j = j + 1;
            end
            break
        end
        
        %choose the reaction
        rho_sum = 0;
        for l = 1:reac_num
            rho_sum = rho_sum + rho(l);
            if r(2,1) * lambda < rho_sum
                reaction_index = l;
                break
            end
        end
        
        %record the X(t)
        while time_scale(j) < t + T
            X(:,j) = k;
            j = j + 1;
        end
        
        %update k and t
        k = k + gamma(:, reaction_index);
        t = t + T;
    end
    simuldataf(i,:,:) = X;
end

%% tQSSA model simulation
var_num = 4;
reac_num = 5;
gamma = [-1 1 1 0 0; 1 -1 -1 0 0; 0 0 0 -1 1; 0 0 0 1 -1]; %Stoichiometric
simuldatay = zeros(simulnum,var_num,scale_size); %simulation record data reduced
for i = 1:simulnum
    fprintf('Simulation %d\n',i);
    t = 0; %current time
    k = [C0; CT-C0; 1; 0];
    X = zeros(var_num, scale_size); %X(t)
    j = 1; %iterator
    %% iteration
    while t <= Tmax
        ctq = 1/2*(k(1) - XT - Km + sqrt((k(1) + XT + Km)^2 - 4*XT*k(1)));
        rho = [kp*k(1); e*k(2)*k(3); f*k(2)*k(4); ka*k(3)*ctq; ki*k(4)];
        lambda = sum(rho);
        
        r = rand([2 1]); %two random numbers r1, r2
        T = -1/lambda * log(r(1));
        
        if t + T > Tmax %end condition
            while j <= scale_size
                X(:,j) = k;
                j = j + 1;
            end
            break
        end
        
        %choose the reaction
        rho_sum = 0;
        for l = 1:reac_num
            rho_sum = rho_sum + rho(l);
            if r(2) * lambda < rho_sum
                reaction_index = l;
                break
            end
        end
        
        %record the X(t)
        while time_scale(j) < t + T
            X(:,j) = k;
            j = j + 1;
        end
        
        %update k and t
        k = k + gamma(:, reaction_index);
        t = t + T;
    end
    simuldatay(i,:,:) = X;
end

%% Mean std calc
%full
simuldatafC = squeeze(simuldataf(:,2,:)+simuldataf(:,4,:));

XmeanfC = mean(simuldatafC,1);
XstdfC = std(simuldatafC,1);

XmeanplusstdfC = XmeanfC + XstdfC;
XmeanminusstdfC = XmeanfC - XstdfC;

%Reduced
simuldatayC = squeeze(simuldatay(:,1,:));

XmeanyC = mean(simuldatayC,1);
XstdyC = std(simuldatayC,1);

XmeanplusstdyC = XmeanyC + XstdyC;
XmeanminusstdyC = XmeanyC - XstdyC;

%% plot
figure(); hold on
p1 = plot(time_scale,XmeanfC,'r','LineWidth',2); 
plot(time_scale,XmeanplusstdfC,'--r','LineWidth',0.1); 
plot(time_scale,XmeanminusstdfC,'--r','LineWidth',0.1);

p2 = plot(time_scale,XmeanyC,'g','LineWidth',2);
plot(time_scale,XmeanplusstdyC,'--g','LineWidth',0.1);
plot(time_scale,XmeanminusstdyC,'--g','LineWidth',0.1);

legend([p1 p2],'Full model','tQSSA')
xlabel("time",'FontSize',15);
ylabel("Cdc2",'FontSize',15);

%% Bimodality check
figure(); hold on
distf = simuldatafC(:,2000*Fs);
distf = distf(:);
disty = simuldatayC(:,2000*Fs);
disty = disty(:);

binrange = 0:1:CT;
p1 = histogram(distf(:),binrange,'FaceColor',[0.8 0 0],'normalization','probability');
p2 = histogram(disty(:),binrange,'FaceColor',[0 0 0.8],'normalization','probability');
legend([p1 p2],{'Full','tQSSA'},'location','Northeast')
xticks([0 10 20 30])
xlim([0 30])
yticks([0 0.13 0.26])
ylim([0 0.26])
box off
legend box off
set(gca,'FontSize',13)
mean(distf)
std(distf)
mean(disty)
std(disty)

%% sample trajectory
figure(); hold on
% i = randperm(10000,1)
i = 1;
temp1 = squeeze(simuldatafC(i,:));
temp2 = squeeze(simuldatayC(i,:));
p3 = plot(time_scale,temp1,'Color','r','LineWidth',1.5);
p4 = plot(time_scale,temp2,'Color','b','LineWidth',1.5);
p3.Color(4) = 0.5;
p4.Color(4) = 0.5;
legend([p3 p4],{'Full','tQSSA'},'location','Northwest')
xlim([0 2000])
xticks([0 2000])
yticks([0 10 20 30])
box off
legend box off
set(gca,'FontSize',13)
%%