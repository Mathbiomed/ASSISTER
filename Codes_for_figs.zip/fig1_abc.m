%% Fig 1 (a) (b) (c)
clear
clc
%% Error term calculation
XTrange = 1:200;
YTrange = 1:200;
Kwrange = zeros(1,31);

YTsize = size(YTrange,2);
XTsize = size(XTrange,2);
Kwsize = size(Kwrange,2);

for i = 0:(Kwsize-1)
    Kwrange(i+1) = 10^(-4+i*0.2); %10^-4 ~ 10^2 log scale
end

meanZ = zeros(XTsize,YTsize,Kwsize);
meanX = zeros(XTsize,YTsize,Kwsize);
variance = zeros(XTsize,YTsize,Kwsize);
tQSSA = zeros(XTsize,YTsize,Kwsize);
tQSSAZ = zeros(XTsize,YTsize,Kwsize);

%% Iteration
for it1 = 1:XTsize
    for it2 = 1:YTsize
        for it3 = 1:Kwsize
            XT = XTrange(it1); 
            YT = YTrange(it2);
            Kw = Kwrange(it3); 
            fprintf('ST=%d / ET=%d / Km=%f \n',YT,XT,Kw); 
            tQSSA(it1, it2, it3) = 1/2*(XT - YT - Kw + sqrt((XT+YT+Kw)^2 - 4*XT*YT));
            tQSSAZ(it1, it2, it3) = 1/2*(XT + YT + Kw - sqrt((XT+YT+Kw)^2 - 4*XT*YT));
            ZT = min(XT,YT);
            pi = zeros(1,ZT);
            meanX(it1,it2,it3) = FSA(XT,YT,Kw, min(XT,YT)+1);
            meanZ(it1,it2,it3) = XT - meanX(it1,it2,it3);
            variance(it1,it2,it3) = -meanX(it1,it2,it3)^2 + (XT - YT - Kw)*meanX(it1,it2,it3) + (XT*Kw);
        end
    end
end
%% Error 
abserr = tQSSA - meanX;
relerrX = abserr./meanX;
relerrZ = abserr./meanZ;

abserrmax = max(abserr,[],3);
relerrXmax = max(relerrX,[],3);
relerrZmax = max(relerrZ,[],3);

%% Fig1 (a)
figure()
imagesc(sqrt(relerrXmax));
caxis([0 10])
xticks([1 100 200])
yticks([1 100 200])
set(gca,'FontSize',13)
set(gca,'YDir','normal')
colorbar('Ticks',[0 5 10],'Ticklabels',[0 25 100])
cmap = flip(hot);
colormap( cmap );  %// create colormap
%% Fig1 (b)
figure()
imagesc(sqrt(relerrXmax)');
caxis([0 10])
xticks([1 100 200])
yticks([1 100 200])
set(gca,'FontSize',13)
set(gca,'YDir','normal')
colorbar('Ticks',[0 5 10],'Ticklabels',[0 25 100])
cmap = flip(hot);
colormap( cmap );  %// create colormap
%% Fig1 (c)
figure()
imagesc(sqrt(relerrZmax));
caxis([0 10])
xticks([1 100 200])
yticks([1 100 200])
set(gca,'FontSize',13)
set(gca,'YDir','normal')
colorbar('Ticks',[0 5 10],'Ticklabels',[0 25 100])
cmap = flip(hot);
colormap( cmap );  %// create colormap
%%
save('fig1 abc data')