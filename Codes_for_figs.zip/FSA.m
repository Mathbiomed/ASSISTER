function f = FSA(XT,YT,K,N) % XT, YT, K_Omega, number of states
    if (N < 1) || (XT < 0) || (YT < 0) || (K < 0)                           % Check if the inputs are nonnegative 
        error('Error: Please check input parameters')
    end
    
    max_state = min(XT+1,N);
    
    if max_state == 1
       f = 0; 
       return
    end
    
    numer = 0;
    denumer = 0;
    if XT < YT
        for l = (max_state-2):(-1):0
            g = K*(XT - l)/(l+1)/(YT - XT + l + 1);
            numer = (numer + l + 1)*g;
            denumer = (denumer + 1)*g;
        end
        f = numer/(denumer+1);
        return
    else
        for l = (max_state-2):(-1):0
            g = K*(YT - l)/(l+1)/(XT - YT + l + 1);
            numer = (numer + l + 1)*g;
            denumer = (denumer + 1)*g;
        end
        f = XT - YT + numer/(denumer+1);
        return
    end 
end