import numpy
import time
import os
import matplotlib.pyplot as plt
import gillespy2
from gillespy2 import Model, Species, Parameter, Reaction

r1 = 10000
r2 = 100
r3 = 0.1
r4 = 0.001
r5 = 0.001
r6 = 0.001

class SS_full1(Model):
 def __init__(self, parameter_values=None):
    # Intialize the Model with a name of your choosing.
    Model.__init__(self, name="SS_full1")

    rate1 = Parameter(name="rate1", expression=100)
    rate2 = Parameter(name="rate2", expression=1)
    rate3 = Parameter(name="rate3", expression=0.1)
    rate4 = Parameter(name="rate4", expression=0.001)
    rate5 = Parameter(name="rate5", expression=0.001)
    rate6 = Parameter(name="rate6", expression=0.001)

    # Add the Parameters to the Model.
    self.add_parameter([rate1, rate2, rate3, rate4, rate5, rate6])

    D = Species(name="D", initial_value=10)
    P = Species(name="P", initial_value=10)
    DP = Species(name="DP", initial_value=0)
    MR = Species(name="MR", initial_value=0)
    MA = Species(name="MA", initial_value=0)
    # Add the Species to the Model.
    self.add_species([D, P, DP, MR, MA])

    kf = Reaction(
            name="kf",
            reactants={D: 1, P: 1}, 
            products={DP: 1},
            rate=rate1
        )

    kb = Reaction(
            name="kb",
            reactants={DP: 1}, 
            products={D: 1, P: 1},
            rate=rate2
        )

    alphaR = Reaction(
            name="alphaR",
            reactants={D: 1}, 
            products={D: 1, MR: 1},
            rate=rate3
        )

    alphaA = Reaction(
            name="alphaA",
            reactants={DP: 1}, 
            products={DP: 1, MA: 1},
            rate=rate4
        )

    betaR = Reaction(
            name="betaR",
            reactants={MR: 1}, 
            products={},
            rate=rate5
        )

    betaA = Reaction(
            name="betaA",
            reactants={MA: 1}, 
            products={},
            rate=rate6
        )

    # Add the Reactions to the Model.
    self.add_reaction([kf, kb, alphaR, alphaA, betaR, betaA])

    # Use NumPy to set the timespan of the Model.
    self.timespan(numpy.linspace(0, 5000, 501))

simul_num = 10000
start1 = time.time()
model = SS_full1()
results1 = model.run(number_of_trajectories = simul_num)
print(time.time() - start1)
