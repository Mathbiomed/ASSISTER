%% XT Kw heatmap
clear
clc 
XTrange = 1:100;
Kwrange = zeros(1,301);
XTsize = size(XTrange,2);
Kwsize = size(Kwrange,2);
for i = 0:(Kwsize-1)
    Kwrange(i+1) = 10^(-4+i*0.02); %10^-2 ~ 10^2 log scale
end
meanX = zeros(XTsize,Kwsize);
tQSSAX = zeros(XTsize,Kwsize);
FSAX2 = zeros(XTsize,Kwsize);
FSAX3 = zeros(XTsize,Kwsize);
FSAX4 = zeros(XTsize,Kwsize);
FSAX5 = zeros(XTsize,Kwsize);
upperbound = zeros(XTsize,Kwsize);

for it1 = 1:XTsize
    for it2 = 1:Kwsize
        XT = XTrange(it1);
        Kw = Kwrange(it2);
        fprintf('XT=%d / Kw=%f \n',XT,Kw);
        YT = XT;
        tQSSAX(it1, it2) = 1/2*(XT - YT - Kw + sqrt((YT + XT + Kw)^2 - 4*XT*YT));
        FSAX2(it1, it2) = FSA(XT,YT,Kw,2);
        FSAX3(it1, it2) = FSA(XT,YT,Kw,3);
        FSAX4(it1, it2) = FSA(XT,YT,Kw,4);
        FSAX5(it1, it2) = FSA(XT,YT,Kw,5);
        meanX(it1, it2) = FSA(XT,YT,Kw, XT+5);
        upperbound(it1,it2) = 1/sqrt(XT*Kw);
    end
end

%% Relative
relerrtq = abs(tQSSAX-meanX)./meanX;
relerr2 = abs(FSAX2-meanX)./meanX;
relerr3 = abs(FSAX3-meanX)./meanX;
relerr4 = abs(FSAX4-meanX)./meanX;
relerr5 = abs(FSAX5-meanX)./meanX;

%% tQSSA
figure()
imagesc(Kwrange,XTrange,log10(relerrtq)); hold on
colorbar
set(gca, 'Xscale','log')
set(gca,'XMinorTick','off')
set(gca,'YDir','normal')
yticks([1 50 100])
xticks([0.0001 0.01 1 100])
set(gca,'FontSize',13)

caxis([-2 2])
colorbar('Ticks',[-2 0 2],'Ticklabels',[0.01 1 100])
cmap = flip(hot);
colormap(cmap);


tQSSAline = sum((relerrtq>0.1));
image = tQSSAline(146:216);
domain = Kwrange(146:216);
plot(domain, image,'k-','LineWidth',2); hold on

UBline = sum((upperbound>1/sqrt(10)));
image2 = UBline(150:251);
domain2 = Kwrange(150:251);
plot(domain2, image2,'--','Color',[.6 .6 .6],'LineWidth',2)


%% FSP
figure()
imagesc(Kwrange,XTrange,log10(relerr2)); hold on
set(gca, 'Xscale','log')
set(gca,'XMinorTick','off')
set(gca,'YDir','normal')
yticks([1 50 100])
cmap = flip(hot);
colormap(cmap)
caxis([-2 2])
colorbar('Ticks',[-2 0 2],'Ticklabels',[0.01 1 100])
yticks([1 50 100])
xticks([0.0001 0.01 1 100])
set(gca,'FontSize',13)


tQSSAline = sum((relerrtq>0.1));
image = tQSSAline(146:216);
domain = Kwrange(146:216);
plot(domain, image,'k-','LineWidth',2); hold on

FSP2line = sum((relerr2<0.1));
image = FSP2line(70:end);
domain = Kwrange(70:end);
plot(domain, image,'-','Color',[216, 55, 16]/255,'LineWidth',2); hold on

FSP5line = sum((relerr5<0.1));
image = FSP5line(152:end);
domain = Kwrange(152:end);
plot(domain, image,'--','Color',[1.0000 1.0000 0.6],'LineWidth',2); hold on
