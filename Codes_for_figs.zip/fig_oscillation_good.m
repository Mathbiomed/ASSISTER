%% Fig Oscillation tQSSA Bad
%% initialization
clear
clc
rng('shuffle')
Tmax = 100000; %maximal simualtion time
Fs = 10;
period = 1/Fs;
time_scale = 0:period:Tmax; % record time scale
scale_size = length(time_scale); % number of record time
 
AT = 5;
%fast reaction const
kf = 1000000; %bidning
kb = 100; %unbinding
Km = kb/kf;

%slow reaction const 
alphaM = 20; %M1 transcription
betaM = 1;
alphaP = 1.5; 
betaP = 1; 
alphaR = 1;
betaR = 1;
%% Full model
t = 0; %current time

gamma = [-1 1 0 0 0 0 0 0 0 0 0 0 1; -1 1 0 0 0 0 0 0 0 0 1 -1 0; 1 -1 0 0 0 0 0 0 0 0 0 0 -1;
    0 0 1 -1 0 0 0 0 0 0 0 0 0; 0 0 0 0 1 -1 0 0 0 0 0 0 0; 0 0 0 0 0 0 1 -1 0 0 0 0 0; 0 0 0 0 0 0 0 0 1 -1 0 0 0]; %Stoichiometric

var_num = 7; % number of variables
reac_num = 13; % number of reactions

k = [AT;AT;0;0;0;0;0]; %initial condition

X = zeros(var_num,scale_size); %X(t)
j = 1;
marker = 1000;
%% iteration
while t <= Tmax
    if t > marker
        fprintf('%f\n',t);
        marker = marker + 1000;
    end
    %Omega = 1
    rho = [kf*k(1)*k(2); kb*k(3); alphaM*k(1); betaM*k(4); alphaP*k(4); betaP*k(5); 
        alphaP*k(5); betaP*k(6); alphaP*k(6); betaP*k(7); alphaR*k(7); betaR*k(2); betaR*k(3)];
    lambda = sum(rho);
    
    %     if lambda == 0 %reactions do not happen
    %        while j <= scale_size
    %         X(:,j) = k;
    %         j = j + 1;
    %        end
    %        break
    %     end
    
    r = rand([2 1]); %two random numbers r1, r2
    T = -1/lambda * log(r(1));
    
    if t + T > Tmax %end condition
        while j <= scale_size
            X(:,j) = k;
            j = j + 1;
        end
        
        break
    end
    
    %choose the reaction
    rho_sum = 0;
    for l = 1:reac_num
        rho_sum = rho_sum + rho(l);
        if r(2) * lambda < rho_sum
            reaction_index = l;
            break
        end
    end
    
    %record the X(t)
    while time_scale(j) < t + T
        X(:,j) = k;
        j = j + 1;
    end
    
    %update k and t
    k = k + gamma(:, reaction_index);
    t = t + T;
end

X(2,:) = X(2,:) + X(3,:); %RT

%% Reduced model
t = 0; %current time

gamma = [ 0 0 0 0 0 0 0 0 1 -1; 1 -1 0 0 0 0 0 0 0 0; 0 0 1 -1 0 0 0 0 0 0; 
    0 0 0 0 1 -1 0 0 0 0; 0 0 0 0 0 0 1 -1 0 0]; %Stoichiometric
k = [AT;0;0;0;0]; %initial condition

var_num = 6; % number of variables
reac_num = 10;

Y = zeros(var_num,scale_size); %Y(t)
j = 1;
marker = 1000;
%% iteration
while t <= Tmax
    if t > marker
        fprintf('%f\n',t);
        marker = marker + 1000;
    end
    %Omega = 1
    AtQ = 1/2*(AT - k(1) - Km + sqrt((k(1) + AT + Km)^2 - 4*AT*k(1)));
    rho = [alphaM*AtQ; betaM*k(2); alphaP*k(2); betaP*k(3); alphaP*k(3);
         betaP*k(4); alphaP*k(4); betaP*k(5); alphaR*k(5); betaR*k(1)];
    lambda = sum(rho);
    
    r = rand([2 1]); %two random numbers r1, r2
    T = -1/lambda * log(r(1));
    
    if t + T > Tmax %end condition
        while j <= scale_size
            Y(:,j) = [AtQ;k];
            j = j + 1;
        end
        break
    end
    
    %choose the reaction
    rho_sum = 0;
    for l = 1:reac_num
        rho_sum = rho_sum + rho(l);
        if r(2) * lambda < rho_sum
            reaction_index = l;
            break
        end
    end
    
    %record the X(t)
    while time_scale(j) < t + T
        Y(:,j) = [AtQ;k];
        j = j + 1;
    end
    
    %update k and t
    k = k + gamma(:, reaction_index);
    t = t + T;
end

%% peak to peak
cut = 1*Fs; %Remove first tansient part
width = 0.7; %minimum peak width(smoothing the peak)
distance = 1; %minimum peak distance(do not detect too many peaks)
height1 = 3;
height2 = 10;
[fpksu, flocsu] = findpeaks(X(2,cut:scale_size),time_scale(cut:scale_size),'MinPeakWidth',width,'MinPeakDistance',distance,'MinPeakHeight',height1);
[rpksu, rlocsu] = findpeaks(Y(2,cut:scale_size),time_scale(cut:scale_size),'MinPeakWidth',width,'MinPeakDistance',distance,'MinPeakHeight',height1);

[fpksl, flocsl] = findpeaks(-X(2,cut:scale_size),time_scale(cut:scale_size),'MinPeakWidth',width,'MinPeakDistance',distance,'MinPeakHeight',-height2);
[rpksl, rlocsl] = findpeaks(-Y(2,cut:scale_size),time_scale(cut:scale_size),'MinPeakWidth',width,'MinPeakDistance',distance,'MinPeakHeight',-height2);

 %% remove double checked peak
lenfu = length(flocsu);
lenfl = length(flocsl);
lenru = length(rlocsu);
lenrl = length(rlocsl);

floc = [flocsu(1); flocsl(1)];
fpeak = [fpksu(1); fpksl(1)];
rloc = [rlocsu(1); rlocsl(1)];
rpeak = [rpksu(1); rpksl(1)];

i = 1;
j = 1;
if flocsu(1) < flocsl(1)
    tokenf = 1;
    while 1
        while flocsu(i) < flocsl(j) && i < lenfu
            i = i + 1;
        end
        if flocsu(i) > flocsl(j)
            while flocsl(j) < flocsu(i) && j < lenfl
                j = j + 1;
            end
            if flocsu(i) < flocsl(j)
                floc = [floc, [flocsu(i); flocsl(j)]];
                fpeak = [fpeak, [fpksu(i); fpksl(j)]];
            end
            if j == lenfl
                break
            end
        end
        if i == lenfu
            break
        end
    end
else
    tokenf = 0;
    while 1
        while flocsu(i) > flocsl(j) && j < lenfl
            j = j + 1;
        end
        if flocsu(i) < flocsl(j)
            while flocsl(j) > flocsu(i) && i < lenfu
                i = i + 1;
            end
            if flocsu(i) > flocsl(j)
                floc = [floc, [flocsu(i); flocsl(j)]];
                fpeak = [fpeak, [fpksu(i); fpksl(j)]];
            end
            if i == lenfu
                break
            end
        end
        if j == lenfl
            break
        end
    end
end
i = 1;
j = 1;
if rlocsu(1) < rlocsl(1)
    tokenr = 1;
    while 1
        while rlocsu(i) < rlocsl(j) && i < lenru
            i = i + 1;
        end
        if rlocsu(i) > rlocsl(j)
            while rlocsl(j) < rlocsu(i) && j < lenrl
                j = j + 1;
            end
            if rlocsu(i) < rlocsl(j)
                rloc = [rloc, [rlocsu(i); rlocsl(j)]];
                rpeak = [rpeak, [rpksu(i); rpksl(j)]];
            end
            if j == lenrl
                break
            end
        end
        if i == lenru
            break
        end
    end
else
    tokenr = 0;
    while 1
        while rlocsu(i) > rlocsl(j) && j < lenrl
            j = j + 1;
        end
        if rlocsu(i) < rlocsl(j)
            while rlocsl(j) > rlocsu(i) && i < lenru
                i = i + 1;
            end
            if rlocsu(i) > rlocsl(j)
                rloc = [rloc, [rlocsu(i); rlocsl(j)]];
                rpeak = [rpeak, [rpksu(i); rpksl(j)]];
            end
            if i == lenru
                break
            end
        end
        if j == lenrl
            break
        end
    end
end

flocsu = floc(1,:);
flocsl = floc(2,:);
fpksu = fpeak(1,:);
fpksl = fpeak(2,:);

rlocsu = rloc(1,:);
rlocsl = rloc(2,:);
rpksu = rpeak(1,:);
rpksl = rpeak(2,:);

%% Sample drawing
ylimit = 100;
figure()
cut = 1*Fs;
window = 100*Fs;
p(1) = subplot(2,1,1); hold on
plot(time_scale(cut:window),X(2,cut:window),'r','LineWidth',2);
flocsu1 = flocsu(flocsu<window);
flocsl1 = flocsl(flocsl<window);
plot(flocsu1,fpksu(1:length(flocsu1)),'gv','MarkerFaceColor','g');
plot(flocsl1,-fpksl(1:length(flocsl1)),'kv','MarkerFaceColor','k');
xlim([cut window]/Fs)

p(2) = subplot(2,1,2); hold on
plot(time_scale(cut:window),Y(2,cut:window),'b','LineWidth',2);
rlocsu1 = rlocsu(rlocsu<window);
rlocsl1 = rlocsl(rlocsl<window);
plot(rlocsu1,rpksu(1:length(rlocsu1)),'gv','MarkerFaceColor','g');
plot(rlocsl1,-rpksl(1:length(rlocsl1)),'kv','MarkerFaceColor','k');

xlabel("time",'FontSize',15);
ylabel(p(1),"M full",'FontSize',15);
ylabel(p(2),"M reduced",'FontSize',15);
xlim([cut window]/Fs)

ylim(p(1),[0,ylimit])
ylim(p(2),[0,ylimit])

%% Fig 3-1-e
figure();
cut1 = 190*Fs;
window1 = 225*Fs;

left_color = [0 0 0]/255;
right_color = [100 100 100]/255;

p(1) = subplot(2,1,1);
yyaxis left
plot(time_scale(cut1:window1),X(4,cut1:window1),'LineWidth',2,'Color',left_color);
ylim([0 90])
yticks([0 45 90])
set(p(1),'YColor',left_color)

yyaxis right
R1 = plot(time_scale(cut1:window1),X(2,cut1:window1)/AT,'LineWidth',2,'Color',right_color); hold on
R1.Color(4) = 0.65;
set(p(1),'YScale','log')
set(p(1),'YMinorTick','off')
ylim([0.5 100])
yticks([1 10 100])
set(p(1),'YColor',right_color)

box off
xticks([])
xlim([cut1,window1]/Fs)
set(p(1),'Fontsize',13)
set(p(1),'TickDir','out')

cut2 = 30*Fs;
window2 = 65*Fs;

p(2) = subplot(2,1,2);
yyaxis left
plot(time_scale(cut2:window2),Y(3,cut2:window2),'LineWidth',2,'Color',left_color);
ylim([0 90])
yticks([0 45 90])
set(p(2),'YColor',left_color)

yyaxis right
R2 = plot(time_scale(cut2:window2),Y(2,cut2:window2)/AT,'LineWidth',2,'Color',right_color); hold on
R2.Color(4) = 0.65;
set(p(2),'YScale','log')
set(p(2),'YMinorTick','off')
ylim([0.5 100])
yticks([1 10 100])
set(p(2),'YColor',right_color)

box off
set(p(2),'Fontsize',13)
set(p(2),'TickDir','out')
xticks([cut2 (cut2+window2)/2 window2]/Fs)
xticklabels()
xlim([cut2,window2]/Fs)

%% period analysis
figure()
lenf = length(flocsu);
lenr = length(rlocsu);
minlen = min(lenf,lenr);
periodf = flocsu(2:minlen) - flocsu(1:minlen-1);
periodr = rlocsu(2:minlen) - rlocsu(1:minlen-1);
perange = 0:1:20;

% plot
histogram(periodf,perange,'FaceColor',[0.8 0 0],'normalization','probability'); hold on
histogram(periodr,perange,'FaceColor',[0 0 0.8],'normalization','probability');
alpha(.7)
legend('full', 'tQSSA')
box off
legend box off
set(gca,'FontSize',13)

meanperf = mean(periodf);
stdperf = std(periodf);
meanperr = mean(periodr);
stdperr = std(periodr);
