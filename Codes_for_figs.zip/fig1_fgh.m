%% Fig 2 (a) (b) (c)
clear
clc
%% Initialization
%domain
XT = 100;
YT = linspace(0,200,1001);
K_omega = [0.0001 0.001 0.01];

%%
%image
meanXanal = zeros(length(YT),3);
FFanal = zeros(length(YT),3);
tQSSAanal = zeros(length(YT),3);
RelsensX = zeros(length(YT),3);

for i =1:3
    K = K_omega(i);
    for j = 1:length(YT)
        k = YT(j);
        if XT > k
            t = hypergeom(-k + 1, XT - k + 2, -K);
            b = hypergeom(-k, XT - k + 1, -K);
            E = (XT - k) + K * k / (XT - k + 1) * t/b;
        else
            t = hypergeom(-XT + 1, k - XT + 2, -K);
            b = hypergeom(-XT, k - XT + 1, -K);
            E = K * (XT) / (k - XT + 1) * t/b;
        end
        tQSSAanal(j,i) = 1/2*(XT - k - K + sqrt((XT-k-K)^2 + 4*XT*K));
        meanXanal(j,i) = E;
        FFanal(j,i) = -E + (XT - k - K) + (XT*K)/E;
        RelsensX(j,i) = -((2*K - 2*XT + 2*k)/(4*((XT + K + k)^2 - 4*XT*k)^(1/2)) - 1/2)/(XT/2 - K/2 - k/2 + ((XT + K + k)^2 - 4*XT*k)^(1/2)/2);
    end
end

%% Fig1 f
relerrXanal = (tQSSAanal-meanXanal)./meanXanal;
figure()
plot(YT, relerrXanal(:,1),'-','Linewidth',2); hold on
plot(YT, relerrXanal(:,2),'-','Linewidth',2); hold on
plot(YT, relerrXanal(:,3),'-','Linewidth',2); hold on
legend(['K_\Omega = '+string(K_omega(1)),'K_\Omega = '+string(K_omega(2)),'K_\Omega = '+string(K_omega(3))])
set(gca,'FontSize',13)
box off
legend boxoff  
xticks([100 200])
yticks([0 relerrXanal(YT == 100,3) relerrXanal(YT == 100,2) relerrXanal(YT == 100,1)])
xticklabels([1 2])

% %% Fig1 g
% figure()
% plot(YT, FFanal(:,1),'-','Linewidth',2); hold on
% plot(YT, FFanal(:,2),'-','Linewidth',2); hold on
% plot(YT, FFanal(:,3),'-','Linewidth',2); hold on
% legend(['K_\Omega = '+string(K_omega(1)),'K_\Omega = '+string(K_omega(2)),'K_\Omega = '+string(K_omega(3))])
% set(gca,'FontSize',13)
% xticks([25 50])
% yticks([0 0.5 1])
% xticklabels([1 2])
% box off
% legend boxoff  

%% Fig1 h
figure()
c1 = plot(YT, 2*RelsensX(:,1),'-','Linewidth',2); hold on
c2 = plot(YT, 2*RelsensX(:,2),'-','Linewidth',2); hold on
c3 = plot(YT, 2*RelsensX(:,3),'-','Linewidth',2); hold on
plot(XT, 1,'ko','Linewidth',1.5,'MarkerSize',10); hold on
plot(XT, sqrt(10),'ko','Linewidth',1.5,'MarkerSize',10); hold on
plot(XT, 10,'ko','Linewidth',1.5,'MarkerSize',10); hold on
xticks([100 200])
xticklabels([1 2])
yticks([0 1 sqrt(10) 10])
set(gca,'FontSize',13)
legend([c1 c2 c3],['K_\Omega = '+string(K_omega(1)),'K_\Omega = '+string(K_omega(2)),'K_\Omega = '+string(K_omega(3))])
box off
legend boxoff  

%%
save('fig1 de data')