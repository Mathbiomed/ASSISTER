%% Fig1 (e)
Tmax = 10; %maximal simualtion time
XT = 100;
YT = 100;
kf = 10000;
kb = 1;
gamma = [-1 1 ; -1 1; 
    1 -1]; %Stoichiometric

var_num = 3;
reac_num = 2;

k = [XT;YT;0];
t = 0; %current time
timeline = t;
X = k; %X(t)
j = 1; %iterator
while t <= Tmax
    %Omega = 1
    rho = [kf*k(1)*k(2); kb*k(3)];
    lambda = sum(rho);

    r = rand([2 1]); %two random numbers r1, r2
    T = -1/lambda * log(r(1,1));

    %choose the reaction
    rho_sum = 0; 
    for i = 1:reac_num
        rho_sum = rho_sum + rho(i,1);
        if r(2,1) * lambda < rho_sum
            reaction_index = i;
            break
        end
    end
    
    if t + T > Tmax %end condition
        break
    end
    
    %update k and t
    k = k + gamma(:, reaction_index);
    t = t + T;
    
    %record the X(t)
    X = [X k];
    timeline = [timeline t];
end

%% plotting
sstime = timeline((timeline > 0.001));

figure()
stairs(sstime,X(1,(end-length(sstime)+1):end),'-','LineWidth',2,'Color',[0.3 0.3 0.3])
xlim([0.01 0.2])
xticks([0.01 0.2])
xticklabels([0 1])
ylim([0 2])
yticks([0 1 2])
set(gca,'FontSize',13)
box off

%% Fig1 (f)
figure()
state0time = sum(sstime(3:2:end)- sstime(2:2:end-1));
state1time = sum(sstime(2:2:end)- sstime(1:2:end));
totaltime = sstime(end) - sstime(1);
b = bar([0 1],[state0time/totaltime state1time/totaltime],0.07);
xlim([-0.05 1.05])
xticks([0 1/13 10/13 1])
xticklabels({'0', '0.01','0.1', '1'})
yticks([0 0.5 1])

box off;
set(gca,'FontSize',13)
% set(gca,'Yscale','log')
% set(gca,'YMinorTick','off')
b.EdgeColor = 'None';
b.FaceColor = [0.5 0.5 0.5];

%%
save('fig1 fg data')