%% Fig 3 (b)
clear
clc
%% initialization
%maximal simualtion time
Tmax = 5000; 

%parameters
DT = 10; %total DNA
PT = 10; %total P

%fast reaction const
kf = 100; %binding
kb = 1; %unbinding

%slow reaction const
k1 = 0.1; %M1 transcription
k2 = 0.001; %M2 transcription
kd1 = 0.001; %M1 Degradation
kd2 = 0.001; %M2 Degradation

time_scale = 0:1:Tmax; % record time scale
scale_size = length(time_scale); % number of record time
var_num = 5; % number of variables

simulnum = 10000; % number of simulations
simuldataf = zeros(simulnum,var_num,scale_size); %simulation record data full
simuldatar = zeros(simulnum,var_num,scale_size); %simulation record data reduced

%% full model simulation
reac_num = 6; % number of reactions
gamma = [-1 1 0 0 0 0; -1 1 0 0 0 0; 
    1 -1 0 0 0 0; 0 0 1 0 -1 0; 0 0 0 1 0 -1]; %stoichiometric

%% Simulation
for i = 1:simulnum
    fprintf('Simulation %d\n',i);
    t = 0; %current time
    k = [DT;PT;0;0;0]; %Current state
    X = zeros(var_num, scale_size); %X(t) record
    j = 1; %iterator
    %% iteration
    while t <= Tmax
        %Omega = 1
        rho = [kf*k(1)*k(2); kb*k(3); k1*k(1);
            k2*k(3); kd1*k(4); kd2*k(5)];
        lambda = sum(rho);
        
        r = rand([2 1]); %two random numbers r1, r2
        T = -1/lambda * log(r(1,1));
        
        if t + T > Tmax %end condition
            while j <= scale_size
                X(:,j) = k;
                j = j + 1;
            end
            break
        end
        
        %choose the reaction
        rho_sum = 0;
        for l = 1:reac_num
            rho_sum = rho_sum + rho(l,1);
            if r(2,1) * lambda < rho_sum
                reaction_index = l;
                break
            end
        end
        
        %record the X(t)
        while time_scale(1,j) < t + T
            X(:,j) = k;
            j = j + 1;
        end
        
        %update k and t
        k = k + gamma(:, reaction_index);
        t = t + T;
    end
    simuldataf(i,:,:) = X;
end

%% reduced model simulation
Km = kb/kf;
var_num = 5; % number of variables
reac_num = 4; % number of reactions

%tQSSA for DNA:P
DPtQ = 1/2*(DT + PT + Km - sqrt((DT + PT + Km)^2 - 4*DT*PT)); 

%Stoichiometric
gamma = [0 0 0 0; 0 0 0 0; 
    0 0 0 0; 1 0 -1 0; 0 1 0 -1]; 

for i = 1:simulnum
    fprintf('Simulation %d\n',i);
    t = 0; %current time
    k = [DT - DPtQ ; PT - DPtQ ; DPtQ ; 0 ; 0]; 
    X = zeros(var_num, scale_size); %Reduced X(t)
    j = 1; %iterator
    %% iteration
    while t <= Tmax
        %Omega = 1
        rho = [k1*(DT - DPtQ);
            k2*DPtQ; kd1*k(4); kd2*k(5)];
        lambda = sum(rho);
        
        r = rand([2 1]); %two random numbers r1, r2
        T = -1/lambda * log(r(1,1));
        
        if t + T > Tmax %end condition
            while j <= scale_size
                X(:,j) = k;
                j = j + 1;
            end
            break
        end
        
        %choose the reaction
        rho_sum = 0;
        for l = 1:reac_num
            rho_sum = rho_sum + rho(l,1);
            if r(2,1) * lambda < rho_sum
                reaction_index = l;
                break
            end
        end
        
        %record the X(t)
        while time_scale(1,j) < t + T
            X(:,j) = k;
            j = j + 1;
        end
        
        %update k and t
        k = k + gamma(:, reaction_index);
        t = t + T;
    end
    simuldatar(i,:,:) = X;
end
Xmeanf = squeeze(mean(simuldataf,1));
Xstdf = squeeze(std(simuldataf,1));

Xmeanr = squeeze(mean(simuldatar,1));
Xstdr = squeeze(std(simuldatar,1));

%% mean std
Xmeanplusstdf = Xmeanf + Xstdf;
Xmeanminusstdf = Xmeanf - Xstdf;
Xmeanplusstdr = Xmeanr + Xstdr;
Xmeanminusstdr = Xmeanr - Xstdr;

%% M1 mean trajectory
figure()
patch([time_scale fliplr(time_scale)], [Xmeanplusstdf(4,:)  fliplr(Xmeanminusstdf(4,:))],[0.8 0 0], 'EdgeColor','None'); hold on;
alpha(.3)
p1 = plot(time_scale,Xmeanf(4,:),'r','LineWidth',2); hold on

patch([time_scale fliplr(time_scale)], [Xmeanplusstdr(4,:)  fliplr(Xmeanminusstdr(4,:))],[0 0 0.8], 'EdgeColor','None'); hold on;
alpha(.3)
p2 = plot(time_scale,Xmeanr(4,:),'b','LineWidth',2); hold on

legend([p1 p2],{'Full','tQSSA'},'location','northwest')
xlabel("time",'FontSize',15);
xticks([0 2500 5000])
yticks([0 10 30])
ylim([0 40])
box off
legend box off
set(gca,'FontSize',13)

%% M1 Histogram
figure()
histogram(squeeze(simuldataf(:,4,end)),'FaceColor',[0.8 0 0],'Normalization','Probability')
alpha(.7)
box off

figure()
histogram(squeeze(simuldatar(:,4,end)),'FaceColor',[0 0 0.8],'Normalization','Probability')
alpha(.7)
box off

%% M2 mean trajectory
figure()
patch([time_scale fliplr(time_scale)], [Xmeanplusstdf(5,:)  fliplr(Xmeanminusstdf(5,:))],[0.8 0 0], 'EdgeColor','None'); hold on;
alpha(.3)
p3 = plot(time_scale,Xmeanf(5,:),'r','LineWidth',2); hold on

patch([time_scale fliplr(time_scale)], [Xmeanplusstdr(5,:)  fliplr(Xmeanminusstdr(5,:))],[0 0 0.8], 'EdgeColor','None'); hold on;
alpha(.3)
p4 = plot(time_scale,Xmeanr(5,:),'b','LineWidth',2); hold on

legend([p3 p4],{'Full','tQSSA'},'location','northwest')
xlabel("time",'FontSize',15);
xticks([0 2500 5000])
yticks([0 10])
ylim([0 15])
box off
legend box off
set(gca,'FontSize',13)

%% M2 Histogram
figure()
histogram(squeeze(simuldataf(:,5,end)),'FaceColor',[0.8 0 0],'Normalization','Probability')
alpha(.7)
box off

figure()
histogram(squeeze(simuldatar(:,5,end)),'FaceColor',[0 0 0.8],'Normalization','Probability')
alpha(.7)
box off

%% save
save('ss bad data','-v7.3')
